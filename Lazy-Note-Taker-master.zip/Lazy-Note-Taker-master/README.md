# Lazy-Note-Taker

## Don't just copy notes, extract them!

Lazy Note Taker is an Android note taking app that uses Tesseract OCR to extract text contained in an image or from camera.


## Steps to install
