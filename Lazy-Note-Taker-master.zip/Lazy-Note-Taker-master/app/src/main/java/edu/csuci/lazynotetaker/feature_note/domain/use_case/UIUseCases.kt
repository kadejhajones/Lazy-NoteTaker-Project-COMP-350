package edu.csuci.lazynotetaker.feature_note.domain.use_case

data class UIUseCases(
    val setUIUseCase : SetUIUseCase
)
