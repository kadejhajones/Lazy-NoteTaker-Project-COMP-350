package edu.csuci.lazynotetaker.feature_note.presentation.add_edit_note

data class AddEditNoteState(
    var isColorSectionVisible: Boolean = false

)
